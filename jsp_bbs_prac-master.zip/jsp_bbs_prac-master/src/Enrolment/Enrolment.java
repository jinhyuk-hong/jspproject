package Enrolment;

public class Enrolment {
	private String stuID;
	private String gradeName;
	private String userID;
	private String stuList;
	private String stuDate;
	private int stuAvailable;
	public String getStuID() {
		return stuID;
	}
	public void setStuID(String stuID) {
		this.stuID = stuID;
	}
	public String getGradeName() {
		return gradeName;
	}
	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getStuList() {
		return stuList;
	}
	public void setStuList(String stuList) {
		this.stuList = stuList;
	}
	public String getStuDate() {
		return stuDate;
	}
	public void setStuDate(String stuDate) {
		this.stuDate = stuDate;
	}
	public int getStuAvailable() {
		return stuAvailable;
	}
	public void setStuAvailable(int stuAvailable) {
		this.stuAvailable = stuAvailable;
	}
	
	
	
	
}
